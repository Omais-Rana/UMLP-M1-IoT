//
//  Expense.swift
//  Expense
//
//  Created by devxcode on 30/09/2025.
//

import Foundation

enum Category: String, CaseIterable {
    case Major
    case Minor
    case Other
}

struct Expense: Identifiable {
    
    var id = UUID()
    var title: String
    var amount: Int
    var isPaid: Bool
    var category: Category
    
    static var testData = [
        Expense(title: "Apple", amount: 120000, isPaid: true, category: .Other),
        Expense(title: "Airbnb", amount: 1200, isPaid: false, category: .Major),
        Expense(title: "McDonald", amount: 300, isPaid: false, category: .Minor),
        Expense(title: "Bakery", amount: 10, isPaid: true, category: .Minor),
        Expense(title: "Mechanic", amount: 600, isPaid: false, category: .Major),
    ]
    
}
