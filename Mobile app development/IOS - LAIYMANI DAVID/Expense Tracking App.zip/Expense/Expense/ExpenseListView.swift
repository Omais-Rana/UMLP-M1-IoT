import SwiftUI

struct ContentView: View {
    @State private var selectedTab = "List"
    var body: some View {
        VStack(spacing:0){
            ZStack{
                if selectedTab == "List"
                {
                    ExpenseListView()
                }else if selectedTab == "Overview"
                {
                    OverviewView()
                }
            }.frame(maxHeight: .infinity)
            HStack(spacing: 0){
                Button {
                    selectedTab = "List"
                } label: {
                    VStack(spacing: 4){
                        Image(systemName: "dollarsign.square.fill")
                        Text("Expenses")
                            .font(.caption)
                    }
                }
                .foregroundStyle(selectedTab == "List" ? .blue : .gray)
                .font(.title2)
                .padding()
                .frame(minWidth: 80)
                .background(selectedTab == "List" ? Color.gray.opacity(0.15) : .white)
                .clipShape(Capsule())
                
                Button {
                    selectedTab = "Overview"
                } label: {
                    VStack(spacing: 4){
                        Image(systemName: "chart.bar.fill")
                        Text("Overview")
                            .font(.caption)
                    }
                }
                .foregroundStyle(selectedTab == "Overview" ? .blue : .gray)
                .font(.title2)
                .padding()
                .frame(minWidth: 80)
                .background(selectedTab == "Overview" ? Color.gray.opacity(0.15) : .white)
                .clipShape(Capsule())
            }
            .clipShape(Capsule())
            
        }
    }
}

struct ExpenseListView: View {
    
    @EnvironmentObject var data: ExpenseViewModel
    @State var selectedCategory = "All"
    
    var body: some View {
        NavigationView {
            VStack{
                Picker("Category", selection: $selectedCategory){
                    Text("All").tag("All")
                    ForEach(Category.allCases, id: \.self){ category in
                        Text(category.rawValue).tag(category.rawValue)
                    }
                }.pickerStyle(SegmentedPickerStyle())
                .padding()
                
                List {
                    ForEach(filteredExpenses) { expense in
                        RowView(expense: expense)
                    }
                }
                .listStyle(PlainListStyle())
                .navigationTitle("Expenses")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading){
                        EditButton()
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.gray.opacity(0.1))
                            .clipShape(Capsule())
                    }
                    ToolbarItem(placement: .navigationBarTrailing){
                        NavigationLink("Add", destination: AddExpenseView())
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.gray.opacity(0.1))
                            .clipShape(Capsule())
                    }
                }
            }
        }
    }
    var filteredExpenses : [Expense] {
        if selectedCategory == "All" {
            return data.expenses
        } else {
            return data.expenses.filter {
                $0.category.rawValue == selectedCategory
            }
        }
    }
}



struct ExpenseListView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(ExpenseViewModel())
    }
}
