//
//  OverviewView.swift
//  Expense
//
//  Created by devxcode on 28/03/2023.
//

import SwiftUI

struct OverviewView: View {
    @EnvironmentObject var data: ExpenseViewModel
    
    @State var amount: Int = 0
    @State var category: Category = .Major
    
    var body: some View {
        let majorTotal = data.expenses.filter{
            $0.category ==  .Major
        }.reduce(0){
            $0 + $1.amount
        }
        let minorTotal = data.expenses.filter{
            $0.category ==  .Minor
        }.reduce(0){
            $0 + $1.amount
        }
        let otherTotal = data.expenses.filter{
            $0.category ==  .Other
        }.reduce(0){
            $0 + $1.amount
        }
        let totalExpenses = data.expenses.reduce(0){
            $0 + $1.amount
        }
        NavigationView {
            VStack{
                HStack{
                    Text("Period start date")
                    
                    Spacer()
                    
                    Text("19 Oct 2025")
                        .font(.footnote)
                        .padding(5)
                        .frame(minWidth: 60)
                        .foregroundColor(.black.opacity(0.7))
                        .background(Color.gray.opacity(0.2))
                        .clipShape(Capsule())
                        
                }.font(.title3)
                    .padding()
                    .padding(.horizontal, 10)
                
                HStack{
                    Text("Period end date")
                    
                    Spacer()
                    
                    Text("19 Oct 2025")
                        .font(.footnote)
                        .padding(5)
                        .frame(minWidth: 60)
                        .foregroundColor(.black.opacity(0.7))
                        .background(Color.gray.opacity(0.2))
                        .clipShape(Capsule())
                        
                }.font(.title3)
                .padding()
                .padding(.horizontal, 10)
                
                Divider()
                    .padding(.horizontal, 30)
                
                HStack (spacing:20){
                    Text("Major")
                        .font(.title3)
                        .padding(5)
                        .foregroundStyle(.red)
                        .frame(minWidth: 90)
                        .overlay(Capsule().stroke(.red))
                    
                    Spacer()
                    
                    Text(String(majorTotal) + " " + "$")
                        
                }.font(.title2)
                .padding()
                .padding(.top, 80)
                .padding(.horizontal, 20)
                
                HStack (spacing:20){
                    Text("Minor")
                        .font(.title3)
                        .padding(5)
                        .foregroundStyle(.green)
                        .frame(minWidth: 90)
                        .overlay(Capsule().stroke(.green))
                    
                    Spacer()
                    
                    Text(String(minorTotal) + " " + "$")
                        
                }.font(.title2)
                .padding()
                .padding(.horizontal, 20)
                
                HStack (spacing:20){
                    Text("Other")
                        .font(.title3)
                        .padding(5)
                        .foregroundStyle(.yellow)
                        .frame(minWidth: 90)
                        .overlay(Capsule().stroke(.yellow))
                    
                    Spacer()
                    
                    Text(String(otherTotal) + " " + "$")
                        
                }.font(.title2)
                .padding()
                .padding(.horizontal, 20)
                
                Spacer()
                
                Divider()
                    .padding(.horizontal, 30)
                
                HStack (spacing:20){
                    Text("Total: ")
                    
                    Text(String(totalExpenses) + " " + "$")
                        
                }.font(.title)
                    .bold()
                    .padding()
                    .padding(.bottom, 30)

            }
            .navigationTitle("Overview")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading){
                    EditButton()
                        .foregroundColor(.black)
                        .padding(5)
                        .background(Color.gray.opacity(0.1))
                        .clipShape(Capsule())
                }
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink("Add", destination: AddExpenseView())
                        .foregroundColor(.black)
                        .padding(5)
                        .background(Color.gray.opacity(0.1))
                        .clipShape(Capsule())
                }
            }

        }
    }
}

struct OverviewView_Previews: PreviewProvider {
    static var previews: some View {
        OverviewView()
            .environmentObject(ExpenseViewModel())
    }
}
