//
//  ExpenseViewModel.swift
//  Expense
//
//  Created by devxcode on 30/09/2025.
//

import SwiftUI

class ExpenseViewModel: ObservableObject {
    
    @Published var expenses: [Expense] = []
    
    init() {
        getExpenses()
    }
    
    func getExpenses() {
        expenses.append(contentsOf: Expense.testData)
    }
    
    func addExpense(title: String, amount: Int, category: Category) {
        let newExpense = Expense(title: title, amount: amount, isPaid: false, category: category)
        expenses.append(newExpense)
    }
}
