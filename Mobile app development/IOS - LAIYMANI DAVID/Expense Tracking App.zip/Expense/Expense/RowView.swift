//
//  RowView.swift
//  Expense
//
//  Created by devxcode on 30/09/2025.
//

import SwiftUI

struct RowView: View {
    
    let expense: Expense
    
    var body: some View {
        HStack{
            Text(expense.title)
            
            Spacer()
            
            Text(String(expense.amount) + " " + "$")
            
            Text(expense.category.rawValue)
                .font(.footnote)
                .padding(5)
                .foregroundStyle(expense.category.rawValue == "Other" ? .yellow : expense.category.rawValue == "Major" ? .red : expense.category.rawValue == "Minor" ? .green : .gray)
                .frame(minWidth: 60)
                .overlay(Capsule().stroke(expense.category.rawValue == "Other" ? .yellow : expense.category.rawValue == "Major" ? .red : expense.category.rawValue == "Minor" ? .green : .gray))
                
        }.font(.title2)
        .padding()
    }
}

struct RowView_Previews: PreviewProvider {
    static var previews: some View {
        RowView(expense: Expense.testData[0])
    }
}
