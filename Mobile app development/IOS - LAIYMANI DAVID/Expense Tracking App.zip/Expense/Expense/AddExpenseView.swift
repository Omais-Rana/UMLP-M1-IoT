import SwiftUI

struct AddExpenseView: View {
    
    @State var expenseTitle: String = ""
    @State var amount: Int = 0
    @State var category: Category = .Major
    
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var viewModel: ExpenseViewModel
    
    var body: some View {
        VStack {
            TextField("Enter your expense", text: $expenseTitle)
                .padding(.horizontal)
                .frame(height: 55)
                .background(Color(.systemGray4))
                .cornerRadius(10)
                .padding(.bottom, 10)
            
            TextField("0", value: $amount, formatter: NumberFormatter.init()).keyboardType(.decimalPad)
                .padding(.horizontal)
                .frame(height: 55)
                .background(Color(.systemGray4))
                .cornerRadius(10)
                .padding(.bottom, 10)
            
            
            Picker("Category", selection: $category){
                ForEach(Category.allCases, id: \.self){
                    Text($0.rawValue)
                }
            }.pickerStyle(SegmentedPickerStyle())
            
            Spacer()
            
            Button{
                viewModel.addExpense(title: expenseTitle, amount: amount, category: category)
                self.presentationMode.wrappedValue.dismiss()
            }label: {
                Text("SAVE")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 60)
            }
            
        }.padding(16)
        .navigationTitle("Add an expense")
    }
}

struct AddExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        AddExpenseView()
    }
}
