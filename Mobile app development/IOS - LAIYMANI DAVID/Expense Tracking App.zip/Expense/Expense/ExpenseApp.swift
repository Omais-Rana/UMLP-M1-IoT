//
//  ExpenseApp.swift
//  Expense
//
//  Created by devxcode on 30/09/2025.
//

import SwiftUI

@main
struct ExpenseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(ExpenseViewModel())
        }
    }
}
