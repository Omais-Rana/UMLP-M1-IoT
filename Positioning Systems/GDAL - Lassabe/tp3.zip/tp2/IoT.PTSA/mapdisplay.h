#ifndef MAPDISPLAY_H
#define MAPDISPLAY_H

#include <QWidget>
#include <QRectF>
#include <QPointF>
#include <vector>
#include <ogrsf_frmts.h>

// Struct to store each building alongside its individual envelope
struct BuildingInfo {
    OGRGeometry* geometry;
    OGREnvelope envelope;
};

class MapDisplay : public QWidget {
    Q_OBJECT

    QPointF geo_center;
    QRectF _footprint; // Global bounding box for the entire set
    std::vector<BuildingInfo> _buildings; 
    
    QPoint _last_mouse_pos;
    bool _is_panning = false;

public:
    explicit MapDisplay(QWidget *parent = nullptr);
    ~MapDisplay();

    void set_center(const QPointF &c);
    const QPointF &get_geo_center() const { return geo_center; }

protected:
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    void renderBuilding(const BuildingInfo &info, QPainter &painter);
    void drawTacticalHUD(QPainter &painter);
    QPointF pixelToMode(const QPoint &pos);
};

#endif
