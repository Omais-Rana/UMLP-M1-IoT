#include "mapdisplay.h"
#include <QPainter>
#include <QMouseEvent>
#include <QWheelEvent>
#include <iostream>
#include <iomanip>
#include <gdal_priv.h>
#include <ogr_spatialref.h>

MapDisplay::MapDisplay(QWidget *parent) : QWidget{parent} {
    setlocale(LC_NUMERIC, "C");
    GDALAllRegister();

    // 1. Read from the file with GDAL
    GDALDataset *poDS = (GDALDataset*) GDALOpenEx("map.osm", GDAL_OF_VECTOR, NULL, NULL, NULL);
    if (!poDS) return;

    // 2. Setup Lambert 93 Coordinate Transformation (WGS84 -> L93)
    OGRSpatialReference oSourceSRS, oTargetSRS;
    oSourceSRS.importFromEPSG(4326); // WGS84
    oTargetSRS.importFromEPSG(2154); // Lambert 93
    oSourceSRS.SetAxisMappingStrategy(OAMS_TRADITIONAL_GIS_ORDER);
    OGRCoordinateTransformation *poCT = OGRCreateCoordinateTransformation(&oSourceSRS, &oTargetSRS);

    double gMinX = 1e18, gMinY = 1e18, gMaxX = -1e18, gMaxY = -1e18;

    for (int i = 0; i < poDS->GetLayerCount(); i++) {
        OGRLayer *poLayer = poDS->GetLayer(i);
        poLayer->ResetReading();
        
        OGRFeature *poFeature;
        while ((poFeature = poLayer->GetNextFeature()) != NULL) {
            OGRGeometry *poGeom = poFeature->GetGeometryRef();
            
            // Specifically target Polygon and MultiPolygon types
            if (poGeom != nullptr && (wkbFlatten(poGeom->getGeometryType()) == wkbPolygon || 
                                     wkbFlatten(poGeom->getGeometryType()) == wkbMultiPolygon)) {
                
                // Convert coordinates to Lambert 93
                OGRGeometry *poCopy = poGeom->clone();
                if (poCopy->transform(poCT) == OGRERR_NONE) {
                    
                    // 3. Store each building alongside its envelope
                    BuildingInfo info;
                    info.geometry = poCopy;
                    poCopy->getEnvelope(&info.envelope);
                    _buildings.push_back(info);

                    // Track global bounding box
                    gMinX = std::min(gMinX, info.envelope.MinX);
                    gMinY = std::min(gMinY, info.envelope.MinY);
                    gMaxX = std::max(gMaxX, info.envelope.MaxX);
                    gMaxY = std::max(gMaxY, info.envelope.MaxY);
                } else {
                    delete poCopy;
                }
            }
            OGRFeature::DestroyFeature(poFeature);
        }
    }

    // 4. Compute the envelope of the whole set
    _footprint = QRectF(gMinX, gMinY, gMaxX - gMinX, gMaxY - gMinY);

    // 5. Terminal Output: Total count and Global Bounding Box
    std::cout << "\n--- EXERCISE REPORT ---" << std::endl;
    std::cout << "Total buildings stored: " << _buildings.size() << std::endl;
    std::cout << "Global Envelope (Lambert 93):" << std::endl;
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "  MinX: " << gMinX << " | MaxX: " << gMaxX << " (meters)" << std::endl;
    std::cout << "  MinY: " << gMinY << " | MaxY: " << gMaxY << " (meters)" << std::endl;
    std::cout << "-----------------------\n" << std::endl;

    OGRCoordinateTransformation::DestroyCT(poCT);
    GDALClose(poDS);
}

MapDisplay::~MapDisplay() {
    for (auto &b : _buildings) OGRGeometryFactory::destroyGeometry(b.geometry);
}

void MapDisplay::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter painter{this};
    painter.setRenderHint(QPainter::Antialiasing);

    // Background Gradient
    QLinearGradient bg(0, 0, 0, height());
    bg.setColorAt(0, QColor("#220002"));
    bg.setColorAt(1, QColor("#050000"));
    painter.fillRect(rect(), bg);

    if (_footprint.isNull() || _buildings.empty()) return;

    for (const auto &info : _buildings) {
        renderBuilding(info, painter);
    }
    
    drawTacticalHUD(painter);
}

void MapDisplay::renderBuilding(const BuildingInfo &info, QPainter &painter) {
    auto toPx = [&](double x, double y) {
        double sx = (x - _footprint.left()) * width() / _footprint.width();
        double sy = height() - ((y - _footprint.top()) * height() / _footprint.height());
        return QPointF(sx, sy);
    };

    // Calculate dynamic thickness for zoomed views
    double metersPerPixel = _footprint.width() / width();
    int weight = (metersPerPixel < 1.0) ? 2 : 1;

    // 1. Draw individual envelope (Outline only, no clouding)
    painter.setBrush(Qt::NoBrush);
    painter.setPen(QPen(QColor(255, 0, 0, 35), 1, Qt::DotLine));
    QPointF p1 = toPx(info.envelope.MinX, info.envelope.MinY);
    QPointF p2 = toPx(info.envelope.MaxX, info.envelope.MaxY);
    painter.drawRect(QRectF(p1, p2).normalized());

    // 2. Draw Building Geometry (Beefed up)
    painter.setPen(QPen(QColor("#FF1A1A"), weight));
    painter.setBrush(QColor(180, 0, 20, 130));

    OGRwkbGeometryType type = wkbFlatten(info.geometry->getGeometryType());
    if (type == wkbPolygon) {
        OGRPolygon *poly = (OGRPolygon*)info.geometry;
        OGRLinearRing *ring = poly->getExteriorRing();
        QPolygonF qpoly;
        for (int i = 0; i < ring->getNumPoints(); i++) qpoly << toPx(ring->getX(i), ring->getY(i));
        painter.drawPolygon(qpoly);
    } 
    else if (type == wkbMultiPolygon) {
        OGRMultiPolygon *multi = (OGRMultiPolygon*)info.geometry;
        for (int j = 0; j < multi->getNumGeometries(); j++) {
            OGRPolygon *poly = (OGRPolygon*)multi->getGeometryRef(j);
            OGRLinearRing *ring = poly->getExteriorRing();
            QPolygonF qpoly;
            for (int k = 0; k < ring->getNumPoints(); k++) qpoly << toPx(ring->getX(k), ring->getY(k));
            painter.drawPolygon(qpoly);
        }
    }
}

void MapDisplay::drawTacticalHUD(QPainter &painter) {
    int w = 280, h = 85, m = 20; 
    QRect r(width() - w - m, height() - h - m, w, h);
    
    painter.setBrush(QColor(0, 0, 0, 210));
    painter.setPen(QPen(Qt::red, 1));
    painter.drawRect(r);

    painter.setPen(Qt::white);
    painter.drawText(r.adjusted(15, 20, 0, 0), QString("BUILDINGS: %1").arg(_buildings.size()));
    
    painter.setPen(QColor("#FF4D4D"));
    painter.drawText(r.adjusted(15, 40, 0, 0), "SYSTEM: LAMBERT 93 (EPSG:2154)");
    
    painter.setPen(Qt::gray);
    painter.drawText(r.adjusted(15, 60, 0, 0), "UNIT: METERS (m)");

    painter.setPen(QColor("#FFB6C1"));
    painter.drawText(r.adjusted(15, 78, 0, 0), 
        QString("CENTER: X:%1 Y:%2").arg((int)_footprint.center().x()).arg((int)_footprint.center().y()));
}

QPointF MapDisplay::pixelToMode(const QPoint &pos) {
    double x = _footprint.left() + (pos.x() * _footprint.width() / width());
    double y = _footprint.top() + ((height() - pos.y()) * _footprint.height() / height());
    return QPointF(x, y);
}

void MapDisplay::wheelEvent(QWheelEvent *event) {
    double factor = (event->angleDelta().y() > 0) ? 0.8 : 1.2; 
    QPointF target = pixelToMode(event->pos());
    double nw = _footprint.width() * factor, nh = _footprint.height() * factor;
    _footprint = QRectF(target.x() - (event->pos().x() * nw / width()), 
                        target.y() - ((height() - event->pos().y()) * nh / height()), nw, nh);
    update();
}

void MapDisplay::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) { _is_panning = true; _last_mouse_pos = event->pos(); }
}

void MapDisplay::mouseMoveEvent(QMouseEvent *event) {
    if (_is_panning) {
        QPoint d = event->pos() - _last_mouse_pos;
        _footprint.translate(-(d.x() * _footprint.width() / width()), (d.y() * _footprint.height() / height()));
        _last_mouse_pos = event->pos();
        update();
    }
}

void MapDisplay::mouseReleaseEvent(QMouseEvent *event) { if (event->button() == Qt::LeftButton) _is_panning = false; }
void MapDisplay::set_center(const QPointF &c) { geo_center = c; update(); }
void MapDisplay::resizeEvent(QResizeEvent *event) { Q_UNUSED(event); }
