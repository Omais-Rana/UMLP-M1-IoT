#ifndef MAPDISPLAY_H
#define MAPDISPLAY_H

#include <QWidget>
#include <QRectF>
#include <QPointF>
#include <vector>
#include <ogrsf_frmts.h>

struct BuildingInfo {
    OGRGeometry* geometry;
    OGREnvelope envelope;
};

class MapDisplay : public QWidget {
    Q_OBJECT

    QPointF geo_center;
    QRectF _footprint;
    std::vector<BuildingInfo> _buildings;
    
    double _meshSize = 25.0; 
    int _nx = 0, _ny = 0;           
    std::vector<std::vector<double>> _landuseGrid;

    QPoint _last_mouse_pos;
    bool _is_panning = false;

public:
    explicit MapDisplay(QWidget *parent = nullptr);
    ~MapDisplay();

    void set_center(const QPointF &c);
    const QPointF &get_geo_center() const { return geo_center; }

protected:
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    void performLanduseAnalysis();
    void exportGridResults(const QString &filename);
    void renderTacticalGrid(QPainter &painter);
    void renderBuilding(const BuildingInfo &info, QPainter &painter);
    void drawTacticalHUD(QPainter &painter);
    QPointF pixelToMode(const QPoint &pos);
};

#endif
