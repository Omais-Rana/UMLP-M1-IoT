#include "mapdisplay.h"
#include <QPainter>
#include <QMouseEvent>
#include <QWheelEvent>
#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <gdal_priv.h>
#include <ogr_spatialref.h>

MapDisplay::MapDisplay(QWidget *parent) : QWidget{parent} {
    setlocale(LC_NUMERIC, "C");
    GDALAllRegister(); //

    // 1. Import the file with GDAL
    GDALDataset *poDS = (GDALDataset*) GDALOpenEx("belfort-residences.osm", GDAL_OF_VECTOR, NULL, NULL, NULL);
    if (!poDS) return;

    // 2. Convert content into Lambert93
    OGRSpatialReference oSourceSRS, oTargetSRS;
    oSourceSRS.importFromEPSG(4326); 
    oTargetSRS.importFromEPSG(2154);
    oSourceSRS.SetAxisMappingStrategy(OAMS_TRADITIONAL_GIS_ORDER);
    OGRCoordinateTransformation *poCT = OGRCreateCoordinateTransformation(&oSourceSRS, &oTargetSRS);

    double gMinX = 1e18, gMinY = 1e18, gMaxX = -1e18, gMaxY = -1e18;

    for (int i = 0; i < poDS->GetLayerCount(); i++) {
        OGRLayer *poLayer = poDS->GetLayer(i);
        poLayer->ResetReading();
        OGRFeature *poFeature;
        while ((poFeature = poLayer->GetNextFeature()) != NULL) {
            OGRGeometry *poGeom = poFeature->GetGeometryRef();
            if (poGeom && (wkbFlatten(poGeom->getGeometryType()) == wkbPolygon || wkbFlatten(poGeom->getGeometryType()) == wkbMultiPolygon)) {
                OGRGeometry *poCopy = poGeom->clone();
                if (poCopy->transform(poCT) == OGRERR_NONE) {
                    BuildingInfo info;
                    info.geometry = poCopy;
                    poCopy->getEnvelope(&info.envelope);
                    _buildings.push_back(info);
                    // 3. Find the global bounding box
                    gMinX = std::min(gMinX, info.envelope.MinX); gMinY = std::min(gMinY, info.envelope.MinY);
                    gMaxX = std::max(gMaxX, info.envelope.MaxX); gMaxY = std::max(gMaxY, info.envelope.MaxY);
                } else delete poCopy;
            }
            OGRFeature::DestroyFeature(poFeature);
        }
    }
    _footprint = QRectF(gMinX, gMinY, gMaxX - gMinX, gMaxY - gMinY);

    performLanduseAnalysis();

    OGRCoordinateTransformation::DestroyCT(poCT);
    GDALClose(poDS);
}

MapDisplay::~MapDisplay() {
    for (auto &b : _buildings) OGRGeometryFactory::destroyGeometry(b.geometry);
}

void MapDisplay::performLanduseAnalysis() {
    if (_buildings.empty()) return;

    // Wedge the mesh grid to the bottom left
    _nx = std::ceil(_footprint.width() / _meshSize);
    _ny = std::ceil(_footprint.height() / _meshSize);
    _landuseGrid.assign(_nx, std::vector<double>(_ny, 0.0));

    double originX = _footprint.left();
    double originY = _footprint.top();

    for (const auto &b : _buildings) {
        int iStart = std::max(0, (int)std::floor((b.envelope.MinX - originX) / _meshSize));
        int iEnd = std::min(_nx - 1, (int)std::floor((b.envelope.MaxX - originX) / _meshSize));
        int jStart = std::max(0, (int)std::floor((b.envelope.MinY - originY) / _meshSize));
        int jEnd = std::min(_ny - 1, (int)std::floor((b.envelope.MaxY - originY) / _meshSize));

        for (int i = iStart; i <= iEnd; ++i) {
            for (int j = jStart; j <= jEnd; ++j) {
                double mx = originX + (i * _meshSize);
                double my = originY + (j * _meshSize);
                OGRLinearRing ring;
                ring.addPoint(mx, my); ring.addPoint(mx + _meshSize, my);
                ring.addPoint(mx + _meshSize, my + _meshSize); ring.addPoint(mx, my + _meshSize);
                ring.closeRings();
                OGRPolygon mesh; mesh.addRing(&ring);

                // Compute intersection
                OGRGeometry* intersection = b.geometry->Intersection(&mesh);
                if (intersection && !intersection->IsEmpty()) {
                    double area = 0;
                    OGRwkbGeometryType itype = wkbFlatten(intersection->getGeometryType());
                    
                    // FIX: Cast OGRGeometry* to access get_Area()
                    if (itype == wkbPolygon) {
                        area = ((OGRPolygon*)intersection)->get_Area();
                    } else if (itype == wkbMultiPolygon) {
                        area = ((OGRMultiPolygon*)intersection)->get_Area();
                    }
                    
                    _landuseGrid[i][j] += (area / (_meshSize * _meshSize)) * 100.0;
                    OGRGeometryFactory::destroyGeometry(intersection);
                }
            }
        }
    }
    exportGridResults("landuse_results.txt");
}

void MapDisplay::exportGridResults(const QString &filename) {
    std::ofstream file(filename.toStdString());
    file << _footprint.left() << " " << _footprint.top() << " " << _nx << " " << _ny << " " << _meshSize << "\n";
    for (int i = 0; i < _nx; ++i) {
        for (int j = 0; j < _ny; ++j) {
            if (_landuseGrid[i][j] > 0) file << i << " " << j << " " << std::fixed << std::setprecision(2) << _landuseGrid[i][j] << "\n";
        }
    }
    file.close();
}

void MapDisplay::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter painter{this};
    painter.setRenderHint(QPainter::Antialiasing);
    
    QLinearGradient bg(0, 0, 0, height());
    bg.setColorAt(0, QColor("#220002"));
    bg.setColorAt(1, QColor("#050000"));
    painter.fillRect(rect(), bg);

    if (_footprint.isNull()) return;

    renderTacticalGrid(painter);
    for (const auto &b : _buildings) renderBuilding(b, painter);
    drawTacticalHUD(painter);
}

void MapDisplay::renderTacticalGrid(QPainter &painter) {
    auto toPx = [&](double x, double y) {
        return QPointF((x - _footprint.left()) * width() / _footprint.width(), height() - ((y - _footprint.top()) * height() / _footprint.height()));
    };

    for (int i = 0; i < _nx; ++i) {
        for (int j = 0; j < _ny; ++j) {
            if (_landuseGrid[i][j] > 0.5) {
                int alpha = std::min(200, (int)(_landuseGrid[i][j] * 2.0));
                painter.fillRect(QRectF(toPx(_footprint.left() + i*_meshSize, _footprint.top() + j*_meshSize), 
                                        toPx(_footprint.left() + (i+1)*_meshSize, _footprint.top() + (j+1)*_meshSize)).normalized(), 
                                 QColor(255, 0, 0, alpha));
            }
        }
    }
}

void MapDisplay::renderBuilding(const BuildingInfo &info, QPainter &painter) {
    auto toPx = [&](double x, double y) {
        return QPointF((x - _footprint.left()) * width() / _footprint.width(), height() - ((y - _footprint.top()) * height() / _footprint.height()));
    };

    double mpp = _footprint.width() / width();
    int weight = (mpp < 1.0) ? 2 : 1;

    painter.setBrush(Qt::NoBrush);
    painter.setPen(QPen(QColor(255, 0, 0, 35), 1, Qt::DotLine));
    painter.drawRect(QRectF(toPx(info.envelope.MinX, info.envelope.MinY), toPx(info.envelope.MaxX, info.envelope.MaxY)).normalized());

    painter.setPen(QPen(QColor("#FF1A1A"), weight));
    painter.setBrush(QColor(180, 0, 20, 130));

    OGRwkbGeometryType type = wkbFlatten(info.geometry->getGeometryType());
    if (type == wkbPolygon) {
        OGRPolygon *poly = (OGRPolygon*)info.geometry;
        OGRLinearRing *ring = poly->getExteriorRing();
        QPolygonF qpoly;
        for (int i = 0; i < ring->getNumPoints(); i++) qpoly << toPx(ring->getX(i), ring->getY(i));
        painter.drawPolygon(qpoly);
    } else if (type == wkbMultiPolygon) {
        OGRMultiPolygon *multi = (OGRMultiPolygon*)info.geometry;
        for (int j = 0; j < multi->getNumGeometries(); j++) {
            OGRPolygon *poly = (OGRPolygon*)multi->getGeometryRef(j);
            OGRLinearRing *ring = poly->getExteriorRing();
            QPolygonF qpoly;
            for (int k = 0; k < ring->getNumPoints(); k++) qpoly << toPx(ring->getX(k), ring->getY(k));
            painter.drawPolygon(qpoly);
        }
    }
}

void MapDisplay::drawTacticalHUD(QPainter &painter) {
    int w = 280, h = 85, m = 20; 
    QRect r(width() - w - m, height() - h - m, w, h);
    painter.setBrush(QColor(0, 0, 0, 210));
    painter.setPen(QPen(Qt::red, 1));
    painter.drawRect(r);
    painter.setPen(Qt::white);
    painter.drawText(r.adjusted(15, 20, 0, 0), QString("BUILDINGS: %1").arg(_buildings.size()));
    painter.setPen(QColor("#FF4D4D"));
    painter.drawText(r.adjusted(15, 40, 0, 0), "SYSTEM: LAMBERT 93 (EPSG:2154)");
    painter.setPen(Qt::gray);
    painter.drawText(r.adjusted(15, 55, 0, 0), "UNIT: METERS (m)");
    painter.setPen(QColor("#FFB6C1"));
    painter.drawText(r.adjusted(15, 75, 0, 0), QString("CENTER: X:%1 Y:%2").arg((int)_footprint.center().x()).arg((int)_footprint.center().y()));
}

QPointF MapDisplay::pixelToMode(const QPoint &pos) {
    double x = _footprint.left() + (pos.x() * _footprint.width() / width());
    double y = _footprint.top() + ((height() - pos.y()) * _footprint.height() / height());
    return QPointF(x, y);
}

void MapDisplay::wheelEvent(QWheelEvent *event) {
    double factor = (event->angleDelta().y() > 0) ? 0.8 : 1.2; 
    QPointF target = pixelToMode(event->position().toPoint());
    double nw = _footprint.width() * factor, nh = _footprint.height() * factor;
    _footprint = QRectF(target.x() - (event->position().toPoint().x() * nw / width()), target.y() - ((height() - event->position().toPoint().y()) * nh / height()), nw, nh);
    update();
}

void MapDisplay::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) { _is_panning = true; _last_mouse_pos = event->pos(); }
}

void MapDisplay::mouseMoveEvent(QMouseEvent *event) {
    if (_is_panning) {
        QPoint d = event->pos() - _last_mouse_pos;
        _footprint.translate(-(d.x() * _footprint.width() / width()), (d.y() * _footprint.height() / height()));
        _last_mouse_pos = event->pos();
        update();
    }
}

void MapDisplay::mouseReleaseEvent(QMouseEvent *event) { if (event->button() == Qt::LeftButton) _is_panning = false; }
void MapDisplay::resizeEvent(QResizeEvent *event) { Q_UNUSED(event); }
void MapDisplay::set_center(const QPointF &c) { geo_center = c; update(); }
